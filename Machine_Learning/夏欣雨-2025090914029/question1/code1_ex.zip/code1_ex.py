import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-0.5, 1.5, 200)
y=2*x**5+x**4-11*x**3+7*x**2+2*x

def predict(x,a,b,c,d,e):
    return a*x**5+b*x**4+c*x**3+d*x**2+e*x

def MSE_loss(y,y_hat):
    return np.mean((y-y_hat)**2)

a,b,c,d,e=0,0,0,0,0
lr=0.001
epochs=10000
loss_history=[]

for i in range(epochs):
    y_hat=predict(x,a,b,c,d,e)
    loss=MSE_loss(y,y_hat)
    loss_history.append(loss)
    a-=lr*np.mean(-2*(y-y_hat)*x**5)
    b-=lr*np.mean(-2*(y-y_hat)*x**4)
    c-=lr*np.mean(-2*(y-y_hat)*x**3)
    d-=lr*np.mean(-2*(y-y_hat)*x**2)
    e-=lr*np.mean(-2*(y-y_hat)*x)

print(a,b,c,d,e)
plt.figure()
plt.plot(range(len(loss_history)),loss_history)
plt.xlabel('epoch')
plt.ylabel('loss')
plt.show()