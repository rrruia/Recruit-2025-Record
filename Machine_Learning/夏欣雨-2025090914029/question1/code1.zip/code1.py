import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(-0.5,1.5,100)
y=2*x**5+x**4-11*x**3+7*x**2+2*x
lr=0.01
epochs=1000

fig1=plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.plot(x,y)
plt.xlabel('x')
plt.ylabel('y')

#np.random.seed(555222)
x0=np.random.uniform(-0.5,1.5)
x_history=[x0]
xd=10*x0**4+4*x0**3-33*x0**2+14*x0+2

for i in range(epochs):
    x0=x0-lr*xd
    xd=10*x0**4+4*x0**3-33*x0**2+14*x0+2
    x_history.append(x0)

print(x0)
plt.subplot(1,2,2)
plt.plot(range(len(x_history)),x_history)
plt.xlabel('epoch')
plt.ylabel('x0')
plt.show()