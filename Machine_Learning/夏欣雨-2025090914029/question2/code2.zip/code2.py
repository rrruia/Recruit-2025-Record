import torch
import matplotlib.pyplot as plt
import torch.nn as nn
from torchvision import transforms,datasets
from torch.utils.data import DataLoader

class Lenet(nn.Module):
    def __init__(self):
        super().__init__()
        self.net=nn.Sequential(
            nn.Conv2d(1,6,kernel_size=5,padding=2),nn.Tanh(),
            nn.AvgPool2d(kernel_size=2,stride=2),
            nn.Conv2d(6,16,kernel_size=5),nn.Tanh(),
            nn.AvgPool2d(kernel_size=2,stride=2),
            nn.Conv2d(16,120,kernel_size=5),nn.Tanh(),
            nn.Flatten(),
            nn.Linear(120,84),nn.Tanh(),
            nn.Linear(84,10)
        )
    
    def forward(self,x):
        return self.net(x)
    

transform=transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,),(0.3081,))
])

train_data=datasets.MNIST(root='./data',train=True,download=True,transform=transform)
test_data=datasets.MNIST(root='./data',train=False,download=True,transform=transform)

train_loader=DataLoader(train_data,batch_size=128,shuffle=True)
test_loader=DataLoader(test_data,batch_size=128,shuffle=False)

model=Lenet().to('cuda:0')
loss_f=nn.CrossEntropyLoss()
optimizer=torch.optim.SGD(model.parameters(),lr=0.03, momentum=0.9)
epochs=10
loss_history=[]

for i in range(epochs):
    for x,y in train_loader:
        x,y=x.to('cuda:0'),y.to('cuda:0')
        y_hat=model(x)
        loss=loss_f(y_hat,y)
        loss_history.append(loss.item())
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

fig1=plt.figure()
plt.plot(range(len(loss_history)),loss_history)
plt.xlabel('epoch')
plt.ylabel('loss')
plt.show()

model.eval()
correct = 0
total = 0

with torch.no_grad():
    for x,y in test_loader:
        x,y=x.to('cuda:0'),y.to('cuda:0')
        y_hat=model(x)
        pred = y_hat.argmax(dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)

accuracy = 100 * correct / total
print(f'模型在测试集上的准确率: {accuracy:.2f}%')
